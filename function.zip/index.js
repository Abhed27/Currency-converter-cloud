export const handler = async (event) => {
  try {
    const body = JSON.parse(event.body);

    const from = body.from;
    const to = body.to;
    const amount = body.amount;

    const response = await fetch(
      `https://api.exchangerate.host/convert?from=${from}&to=${to}&amount=${amount}`
    );

    const data = await response.json();

    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify({ result: data.result })
    };

  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Conversion failed" })
    };
  }
};
